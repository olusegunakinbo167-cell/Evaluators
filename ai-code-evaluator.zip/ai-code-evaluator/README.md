# 🧠 AI Code Quality Evaluator

> An intelligent tool for ranking and evaluating AI-generated code responses — built for human-in-the-loop AI training workflows (RLHF, preference ranking, and code quality annotation).

![Node.js](https://img.shields.io/badge/Node.js-18+-green?logo=node.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5.x-blue?logo=typescript)
![License](https://img.shields.io/badge/license-MIT-blue)
![Status](https://img.shields.io/badge/status-active-brightgreen)

---

## 📌 Overview

`ai-code-evaluator` is a full-stack TypeScript tool designed to **systematically rank and compare AI-generated code snippets** across multiple quality dimensions. It is purpose-built for AI data labeling projects that require structured, rubric-based evaluation of model outputs — such as preference ranking tasks used in RLHF (Reinforcement Learning from Human Feedback) pipelines.

The system allows an IT evaluator to:
- Load pairs (or sets) of AI-generated code responses
- Score each response on defined rubric criteria
- Generate a ranked output with justification logs
- Export annotated results to JSON/CSV for training data pipelines

---

## 🧩 Features

| Feature | Description |
|---|---|
| 🔍 **Multi-criteria scoring** | Evaluate code on correctness, efficiency, readability, security, and adherence to prompt |
| ⚖️ **Pairwise comparison engine** | Compare two code responses head-to-head with weighted scoring |
| 📊 **Ranking report generator** | Outputs ranked results with scores and written justifications |
| 🔐 **Security flaw detector** | Static analysis pass flags common vulnerabilities (SQLi, XSS, hardcoded secrets) |
| 📁 **CSV / JSON export** | Annotated results ready for AI training data pipelines |
| 🧪 **Unit tested** | Full test coverage for scoring and ranking logic |

---

## 🗂️ Project Structure

```
ai-code-evaluator/
├── src/
│   ├── api/            # REST API endpoints (Express)
│   ├── components/     # Core evaluation logic modules
│   ├── utils/          # Helpers: scoring, export, formatting
│   ├── types/          # TypeScript interfaces and enums
│   └── index.ts        # App entry point
├── tests/              # Jest unit tests
├── samples/            # Sample AI-generated code pairs for demo
├── .env.example
├── package.json
└── tsconfig.json
```

---

## 🚀 Getting Started

### Prerequisites

- Node.js >= 18
- npm >= 9

### Installation

```bash
git clone https://github.com/YOUR_USERNAME/ai-code-evaluator.git
cd ai-code-evaluator
npm install
cp .env.example .env
```

### Run in Development

```bash
npm run dev
```

### Build for Production

```bash
npm run build
npm start
```

### Run Tests

```bash
npm test
```

---

## 📐 Evaluation Rubric

Each AI-generated code response is scored (0–10) on five dimensions:

| Criterion | Weight | Description |
|---|---|---|
| **Correctness** | 30% | Does the code solve the stated problem accurately? |
| **Efficiency** | 20% | Is time/space complexity appropriate for the use case? |
| **Readability** | 20% | Clear naming, comments, and logical structure |
| **Security** | 20% | No obvious vulnerabilities, safe input handling |
| **Prompt Adherence** | 10% | Does it match the exact requirements given? |

**Weighted Score** = Σ(criterion score × weight)

---

## 🔁 Workflow

```
Input: AI Code Pair (Response A vs Response B)
         │
         ▼
  Load Rubric Criteria
         │
         ▼
  Score Each Response (0-10 per criterion)
         │
         ▼
  Compute Weighted Total
         │
         ▼
  Security Scan Pass
         │
         ▼
  Generate Ranking + Justification Log
         │
         ▼
  Export to JSON / CSV
```

---

## 📦 Sample Output

```json
{
  "task_id": "VOX-2024-0042",
  "prompt": "Write a Node.js function to fetch user data from PostgreSQL",
  "evaluator": "IT Expert",
  "timestamp": "2024-06-16T09:00:00Z",
  "rankings": [
    {
      "rank": 1,
      "response_id": "A",
      "weighted_score": 8.6,
      "scores": {
        "correctness": 9,
        "efficiency": 8,
        "readability": 9,
        "security": 8,
        "prompt_adherence": 10
      },
      "justification": "Response A uses parameterized queries preventing SQL injection, has clear variable naming, and handles async errors properly with try/catch."
    },
    {
      "rank": 2,
      "response_id": "B",
      "weighted_score": 5.9,
      "scores": {
        "correctness": 7,
        "efficiency": 6,
        "readability": 5,
        "security": 4,
        "prompt_adherence": 7
      },
      "justification": "Response B uses string interpolation in SQL query — SQL injection risk. Variable names are unclear and error handling is absent."
    }
  ],
  "preferred": "A",
  "confidence": "high"
}
```

---

## 🛡️ Security Scanner — Detected Patterns

The built-in static scanner flags:

- SQL injection (string-interpolated queries)
- Hardcoded credentials (`password = "..."`, `api_key = "..."`)
- Unsanitized `eval()` usage
- Missing input validation
- XSS vectors in DOM manipulation

---

## 🤝 Contributing

1. Fork the repo
2. Create a feature branch: `git checkout -b feat/your-feature`
3. Commit your changes: `git commit -m 'feat: add your feature'`
4. Push and open a Pull Request

---

## 📄 License

MIT © 2024 — Built for AI training data workflows
