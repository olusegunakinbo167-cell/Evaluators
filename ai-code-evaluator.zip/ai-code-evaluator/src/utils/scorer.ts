// src/utils/scorer.ts

import {
  RubricScores,
  RubricWeights,
  DEFAULT_WEIGHTS,
  EvaluatedResponse,
  CodeResponse,
  SecurityFlag,
} from "../types";

/**
 * Computes a weighted score from a rubric score object.
 */
export function computeWeightedScore(
  scores: RubricScores,
  weights: RubricWeights = DEFAULT_WEIGHTS
): number {
  const weighted =
    scores.correctness * weights.correctness +
    scores.efficiency * weights.efficiency +
    scores.readability * weights.readability +
    scores.security * weights.security +
    scores.promptAdherence * weights.promptAdherence;

  return parseFloat(weighted.toFixed(2));
}

/**
 * Validates that all rubric scores are in range [0, 10].
 */
export function validateScores(scores: RubricScores): boolean {
  return Object.values(scores).every((v) => v >= 0 && v <= 10);
}

/**
 * Ranks evaluated responses by weighted score (descending).
 */
export function rankResponses(
  responses: Array<{ responseId: string; weightedScore: number; scores: RubricScores; securityFlags: SecurityFlag[]; justification: string }>
): EvaluatedResponse[] {
  const sorted = [...responses].sort((a, b) => b.weightedScore - a.weightedScore);
  return sorted.map((r, idx) => ({ ...r, rank: idx + 1 }));
}

/**
 * Determines confidence level based on score spread between top two responses.
 */
export function deriveConfidence(ranked: EvaluatedResponse[]): "low" | "medium" | "high" {
  if (ranked.length < 2) return "high";
  const spread = ranked[0].weightedScore - ranked[1].weightedScore;
  if (spread >= 2.0) return "high";
  if (spread >= 0.8) return "medium";
  return "low";
}

/**
 * Applies a security penalty: each CRITICAL flag reduces score by 1.5,
 * HIGH by 0.8, MEDIUM by 0.3, LOW by 0.1 (capped at 0).
 */
export function applySecurityPenalty(
  score: number,
  flags: SecurityFlag[]
): number {
  const penaltyMap: Record<string, number> = {
    CRITICAL: 1.5,
    HIGH: 0.8,
    MEDIUM: 0.3,
    LOW: 0.1,
  };

  const totalPenalty = flags.reduce(
    (acc, flag) => acc + (penaltyMap[flag.severity] || 0),
    0
  );

  return parseFloat(Math.max(0, score - totalPenalty).toFixed(2));
}
