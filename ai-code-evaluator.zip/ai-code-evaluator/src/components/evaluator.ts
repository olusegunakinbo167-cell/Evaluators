// src/components/evaluator.ts

import {
  EvaluationInput,
  EvaluationResult,
  EvaluatedResponse,
  DEFAULT_WEIGHTS,
} from "../types";
import {
  computeWeightedScore,
  validateScores,
  rankResponses,
  deriveConfidence,
  applySecurityPenalty,
} from "../utils/scorer";
import { scanForSecurityIssues } from "./securityScanner";

/**
 * Runs a full evaluation pass on a set of AI-generated code responses.
 *
 * Steps:
 *  1. Validate all rubric scores
 *  2. Run security scanner on each code response
 *  3. Compute weighted score with security penalty applied
 *  4. Rank all responses
 *  5. Derive confidence based on score spread
 *  6. Return a structured EvaluationResult
 */
export function evaluate(input: EvaluationInput): EvaluationResult {
  const partialRankings: Omit<EvaluatedResponse, "rank">[] = [];

  for (const response of input.responses) {
    const scores = input.manualScores[response.id];

    if (!scores) {
      throw new Error(`No rubric scores provided for response ID: ${response.id}`);
    }

    if (!validateScores(scores)) {
      throw new Error(
        `Invalid scores for response "${response.id}": all values must be between 0 and 10.`
      );
    }

    const securityFlags = scanForSecurityIssues(response.code);
    const rawWeightedScore = computeWeightedScore(scores, DEFAULT_WEIGHTS);
    const penalizedScore = applySecurityPenalty(rawWeightedScore, securityFlags);

    partialRankings.push({
      responseId: response.id,
      weightedScore: penalizedScore,
      scores,
      securityFlags,
      justification: input.justifications[response.id] || "(no justification provided)",
    });
  }

  const rankings = rankResponses(partialRankings);
  const preferred = rankings[0]?.responseId ?? "N/A";
  const confidence = deriveConfidence(rankings);

  return {
    taskId: input.taskId,
    prompt: input.prompt,
    evaluator: input.evaluator,
    timestamp: new Date().toISOString(),
    rankings,
    preferred,
    confidence,
    notes: input.notes,
  };
}
