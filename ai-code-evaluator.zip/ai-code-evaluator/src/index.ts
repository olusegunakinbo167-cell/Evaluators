// src/index.ts

import app from "./api/server";
import { evaluate } from "./components/evaluator";
import { exportToJSON, exportToCSV } from "./utils/exporter";
import { EvaluationInput, Confidence } from "./types";

const PORT = process.env.PORT || 3000;

// ─── Demo: run a sample evaluation on startup ────────────────────────────────

const sampleInput: EvaluationInput = {
  taskId: "VOX-DEMO-001",
  prompt: "Write a Node.js function to fetch a user by ID from PostgreSQL",
  evaluator: "IT Expert",
  confidence: Confidence.HIGH,
  notes: "Response A uses parameterized query; Response B uses string interpolation.",
  responses: [
    {
      id: "A",
      language: "javascript",
      code: `
async function getUserById(id) {
  try {
    const result = await pool.query(
      'SELECT * FROM users WHERE id = $1',
      [id]
    );
    return result.rows[0] ?? null;
  } catch (err) {
    console.error('DB error:', err);
    throw err;
  }
}
      `.trim(),
    },
    {
      id: "B",
      language: "javascript",
      code: `
async function getUserById(id) {
  const result = await pool.query(
    \`SELECT * FROM users WHERE id = \${id}\`
  );
  return result.rows[0];
}
      `.trim(),
    },
  ],
  manualScores: {
    A: {
      correctness: 9,
      efficiency: 8,
      readability: 9,
      security: 9,
      promptAdherence: 10,
    },
    B: {
      correctness: 7,
      efficiency: 7,
      readability: 6,
      security: 3,
      promptAdherence: 8,
    },
  },
  justifications: {
    A: "Uses parameterized queries (prevents SQL injection), proper error handling with try/catch, returns null when user not found.",
    B: "Uses string interpolation in SQL query — critical SQL injection vulnerability. No error handling. Undefined return on missing user.",
  },
};

const result = evaluate(sampleInput);

console.log("\n=== AI Code Evaluator — Demo Result ===\n");
console.log(JSON.stringify(result, null, 2));

const jsonPath = exportToJSON(result, "./output");
const csvPath = exportToCSV(result, "./output");
console.log(`\n✅ Exported JSON: ${jsonPath}`);
console.log(`✅ Exported CSV:  ${csvPath}`);

// ─── Start API server ────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`\n🚀 API server running at http://localhost:${PORT}`);
  console.log(`   POST /evaluate       — submit an evaluation`);
  console.log(`   POST /evaluate/export — evaluate + export to file`);
  console.log(`   GET  /health         — health check`);
});
