// src/types/index.ts

export enum Confidence {
  LOW = "low",
  MEDIUM = "medium",
  HIGH = "high",
}

export interface RubricScores {
  correctness: number;       // 0-10
  efficiency: number;        // 0-10
  readability: number;       // 0-10
  security: number;          // 0-10
  promptAdherence: number;   // 0-10
}

export interface RubricWeights {
  correctness: number;
  efficiency: number;
  readability: number;
  security: number;
  promptAdherence: number;
}

export const DEFAULT_WEIGHTS: RubricWeights = {
  correctness: 0.30,
  efficiency: 0.20,
  readability: 0.20,
  security: 0.20,
  promptAdherence: 0.10,
};

export interface SecurityFlag {
  type: string;
  severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  lineHint?: string;
  description: string;
}

export interface CodeResponse {
  id: string;
  code: string;
  language: string;
}

export interface EvaluatedResponse {
  rank: number;
  responseId: string;
  weightedScore: number;
  scores: RubricScores;
  securityFlags: SecurityFlag[];
  justification: string;
}

export interface EvaluationResult {
  taskId: string;
  prompt: string;
  evaluator: string;
  timestamp: string;
  rankings: EvaluatedResponse[];
  preferred: string;
  confidence: Confidence;
  notes?: string;
}

export interface EvaluationInput {
  taskId: string;
  prompt: string;
  evaluator: string;
  responses: CodeResponse[];
  manualScores: Record<string, RubricScores>;
  justifications: Record<string, string>;
  confidence: Confidence;
  notes?: string;
}
