// src/api/server.ts

import express, { Request, Response, NextFunction } from "express";
import { evaluate } from "../components/evaluator";
import { exportToJSON, exportToCSV } from "../utils/exporter";
import { EvaluationInput } from "../types";

const app = express();
app.use(express.json());

/**
 * POST /evaluate
 * Body: EvaluationInput
 * Returns: EvaluationResult
 */
app.post("/evaluate", (req: Request, res: Response) => {
  try {
    const input: EvaluationInput = req.body;

    if (!input.taskId || !input.prompt || !input.responses?.length) {
      return res.status(400).json({
        error: "Missing required fields: taskId, prompt, responses",
      });
    }

    const result = evaluate(input);
    return res.status(200).json(result);
  } catch (err: any) {
    return res.status(422).json({ error: err.message });
  }
});

/**
 * POST /evaluate/export
 * Body: EvaluationInput + { format: "json" | "csv" }
 * Returns: { filepath, result }
 */
app.post("/evaluate/export", (req: Request, res: Response) => {
  try {
    const { format = "json", ...input }: EvaluationInput & { format?: string } = req.body;
    const result = evaluate(input as EvaluationInput);

    const filepath =
      format === "csv" ? exportToCSV(result) : exportToJSON(result);

    return res.status(200).json({ filepath, result });
  } catch (err: any) {
    return res.status(422).json({ error: err.message });
  }
});

/**
 * GET /health
 */
app.get("/health", (_req: Request, res: Response) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Global error handler
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error(err.stack);
  res.status(500).json({ error: "Internal server error" });
});

export default app;
